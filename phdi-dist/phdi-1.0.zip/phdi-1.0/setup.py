from setuptools import setup


setup(
name='phdi',
version=1.0,
license='BSD',
description='A package for ph data.',
url='https://github.com/CDCgov/phdi',
author='Somebody',
author_email='dlorigan@uw.edu',
long_description=open('README.md').read(),
platforms=['Python 3.9'],
packages=['phdi', 'phdi.cloud', 'phdi.fhir', 'phdi.fhir.cloud', 'phdi.fhir.conversion', 'phdi.fhir.geospatial', 'phdi.fhir.harmonization', 'phdi.fhir.linkage', 'phdi.fhir.tabulation', 'phdi.fhir.transport', 'phdi.geospatial', 'phdi.harmonization', 'phdi.linkage', 'phdi.tabulation', 'phdi.transport'],
include_package_data=True,
zip_safe=False,
classifiers=['Development Status :: 4 - Beta',
            'Operating System :: OS Independent',
            'Programming Language :: Python',
            'Programming Language :: Python :: 3.9',
        'Topic :: Utilities',
        'License :: OSI Approved :: BSD License'])